package com.sanselo.mod.client;

import com.sanselo.mod.entity.BossEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Модель босса с собственными позами: Джон жестикулирует, Санселло замирает и вскидывает руки в атаке. */
public class BossModel extends PlayerModel<BossEntity> {
    public BossModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void setupAnim(BossEntity e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);
        String n = e.hasCustomName() ? e.getCustomName().getString() : "";
        float t = age * 0.1f;
        float rage = 1.0f - e.getHealth() / e.getMaxHealth(); // чем меньше здоровья, тем резче движения

        if (n.contains("jdh")) {
            // театральные жесты: руки взлетают, голова склоняется, он «говорит»
            float k = 1.0f + rage;
            rightArm.xRot = -1.2f + Mth.sin(t * 3.1f * k) * 0.6f;
            rightArm.zRot = 0.4f + Mth.sin(t * 2.3f * k) * 0.5f;
            leftArm.xRot = -0.9f + Mth.sin(t * 2.7f * k + 1f) * 0.7f;
            leftArm.zRot = -0.4f - Mth.sin(t * 1.9f * k) * 0.5f;
            head.zRot = Mth.sin(t * 1.5f) * 0.12f;
            body.yRot = Mth.sin(t * 1.2f) * 0.15f;
        } else if (n.contains("Санселло")) {
            // холодная неподвижность, в бою руки вскинуты
            float up = e.isAggressive() ? 1.0f : 0.25f;
            rightArm.xRot = -1.4f * up + Mth.sin(t * 2f) * 0.05f;
            leftArm.xRot = -1.4f * up + Mth.sin(t * 2f + 1.5f) * 0.05f;
            rightArm.zRot = 0.1f;
            leftArm.zRot = -0.1f;
            head.xRot += Mth.sin(t * 0.8f) * 0.04f;
        } else {
            // Вея и эхо: руки вперёд, лёгкое покачивание
            rightArm.xRot = -0.9f + Mth.sin(t * 2f) * 0.08f;
            leftArm.xRot = -0.9f + Mth.sin(t * 2f + 1.5f) * 0.08f;
        }
        // внешний слой (рукава, шляпа) повторяет позу
        rightSleeve.copyFrom(rightArm);
        leftSleeve.copyFrom(leftArm);
        hat.copyFrom(head);
        jacket.copyFrom(body);
    }
}
