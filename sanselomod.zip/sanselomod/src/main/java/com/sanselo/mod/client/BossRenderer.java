package com.sanselo.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.sanselo.mod.entity.BossEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Скин зависит от имени босса: Джон, Санселло или Эхо трещины (Вея). */
public class BossRenderer extends HumanoidMobRenderer<BossEntity, BossModel> {
    private static final ResourceLocation ECHO = new ResourceLocation("sanselomod", "textures/entity/echo_boss.png");
    private static final ResourceLocation JDH = new ResourceLocation("sanselomod", "textures/entity/jdh.png");
    private static final ResourceLocation SANS = new ResourceLocation("sanselomod", "textures/entity/sanselo.png");

    public BossRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new BossModel(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.6f);
    }

    private static String nameOf(BossEntity e) {
        return e.hasCustomName() ? e.getCustomName().getString() : "";
    }

    @Override
    protected void scale(BossEntity e, PoseStack ps, float partial) {
        String n = nameOf(e);
        float s = (n.contains("jdh") || n.contains("Санселло")) ? 1.1f
                : 1.25f + 0.03f * (float) Math.sin((e.tickCount + partial) / 6.0);
        ps.scale(s, s, s);
    }

    @Override
    public ResourceLocation getTextureLocation(BossEntity e) {
        String n = nameOf(e);
        if (n.contains("jdh")) return JDH;
        if (n.contains("Санселло")) return SANS;
        return ECHO;
    }
}
