package com.sanselo.mod.registry;

import com.sanselo.mod.SanseloMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public class ModDimensions {
    public static final ResourceKey<Level> RIFT =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(SanseloMod.MODID, "rift"));
}
