package com.sanselo.mod.story;

import com.sanselo.mod.SanseloMod;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraftforge.items.ItemHandlerHelper;

/** Выдаёт игроку карту с отметкой ближайшей структуры мода. */
public final class MapGiver {
    private MapGiver() {}

    public static void crater(ServerPlayer sp) { give(sp, "meteor_crater", "Карта кратера", MapDecoration.Type.TARGET_X); }
    public static void lab(ServerPlayer sp) { give(sp, "ruined_lab", "Карта лаборатории", MapDecoration.Type.RED_X); }
    public static void library(ServerPlayer sp) { give(sp, "forgotten_library", "Карта Библиотеки забытого", MapDecoration.Type.MANSION); }

    private static void give(ServerPlayer sp, String structure, String title, MapDecoration.Type type) {
        try {
            ServerLevel level = sp.getServer().overworld();
            BlockPos origin = sp.level().dimension() == Level.OVERWORLD ? sp.blockPosition() : level.getSharedSpawnPos();
            TagKey<Structure> tag = TagKey.create(Registries.STRUCTURE, new ResourceLocation(SanseloMod.MODID, structure));
            BlockPos pos = level.findNearestMapStructure(tag, origin, 100, false);
            if (pos == null) {
                sp.sendSystemMessage(Component.literal("Карта: рядом пока нет такого места. Исследуй мир дальше и вызови /story map ещё раз.")
                        .withStyle(ChatFormatting.GRAY));
                return;
            }
            ItemStack map = MapItem.create(level, pos.getX(), pos.getZ(), (byte) 2, true, true);
            MapItem.renderBiomePreviewMap(level, map);
            MapItemSavedData.addTargetDecoration(map, pos, "+", type);
            map.setHoverName(Component.literal(title));
            ItemHandlerHelper.giveItemToPlayer(sp, map);
            sp.sendSystemMessage(Component.literal(title + ": X " + pos.getX() + ", Z " + pos.getZ()).withStyle(ChatFormatting.AQUA));
        } catch (Exception e) {
            sp.sendSystemMessage(Component.literal("Не удалось создать карту.").withStyle(ChatFormatting.GRAY));
        }
    }
}
