package com.sanselo.mod.data;

public enum PlayerRole {
    NONE, SANSELLO, JDH
}
