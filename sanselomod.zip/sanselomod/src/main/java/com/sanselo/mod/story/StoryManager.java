package com.sanselo.mod.story;

import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.fx.Fx;
import com.sanselo.mod.worldgen.StructureGen;
import net.minecraft.core.BlockPos;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.network.ModNetwork;
import com.sanselo.mod.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

/** Сюжет: Сезон 1 «Мироходец без имени» (главы 1-8) и Сезон 2 «Тридцать три трещины» (главы 9-14). */
public final class StoryManager {
    private StoryManager() {}

    private static final String[] TITLES = {
            "Пепел", "Осколок", "Цена Искры", "Гость из трещины", "Миры без людей", "Армия, которая ждала хозяина",
            "Правда о черновике", "Выбор мироходца",
            "Тридцать три трещины", "Библиотека забытого", "Дарящий", "Новые Искры", "Охота на Вею", "Вопрос"
    };

    private static final String[] OBJECTIVES = {
            "Найди метеоритный кратер (он отмечен на карте) или руду под землёй и подбери осколок.",
            "Собери 3 осколка. Клоны тоже могут их ронять.",
            "Собери 5 осколков. Назови девочку-клона: /girlname <имя>.",
            "Используй Разрывной портал и войди в Трещину.",
            "Победи 5 Безмолвных клонов.",
            "Победи или пощади 10 клонов (Книга имён, ПКМ по клону) и собери 12 осколков.",
            "В Трещине используй Сердце трещины, чтобы вызвать финального противника.",
            "Выбери концовку кнопкой в чате.",
            "Войди в Трещину ещё 3 раза (Разрывной портал).",
            "Собери 5 Страниц памяти (выпадают из клонов).",
            "Собери в сумме 22 осколка.",
            "Собери 10 Страниц памяти. Береги девочку.",
            "Используй Сердце трещины в Трещине, чтобы вызвать Вею.",
            "Ответь Дарящему: выбери концовку кнопкой в чате."
    };

    private static final String[][] SANSELLO_TEXT = {
            {"Ты приходишь в себя на пепелище и не помнишь своего имени. На стене башни кто-то нацарапал: «Не верь тому, кто помнит».",
             "Один Безмолвный клон идёт за тобой и не нападает. Он повторяет одно слово: «Хозяин»."},
            {"Осколок тёплый, как живой. Он шепчет: «Я просто хотел жить дольше».",
             "С ним приходит первая вспышка памяти: белые лампы, лаборатория, бледное лицо первого клона. Цена: ты на минуту забываешь, как держать меч."},
            {"Каждая вспышка памяти стоит куска тебя самого. Береги самообладание: лишние осколки оставь в сундуке.",
             "К тебе прибивается клон-девочка. Её первый вопрос: «Как меня зовут?» Назови её командой /girlname <имя>, от этого зависит тайная концовка.",
             "Получен Меч из осколка."},
            {"Небо трескается тонкой линией. Из неё выходит гость и сразу устраивает шоу: машет руками, перебивает, ломает четвёртую стену.",
             "«Я верну тебе память, ты отдашь осколки. Нет, не благотворительность, мне нужна Искра!» Так представляется jdh.",
             "Получен Разрывной портал. Войди в Трещину."},
            {"Междумирье: чёрный простор, обломки миров. Здесь три мира без людей: зеркал, застывших часов и тишины.",
             "В мире тишины живёт другой Санселло. Он добр и не создал ни одного клона. Это самое горькое зрелище в твоей жизни."},
            {"Поворот: Безмолвные клоны не убивали мир. Когда магия сорвалась, они пытались вывести людей и гибли сами.",
             "Девочка протягивает тебе Книгу имён. ПКМ по клону пощадит его и назовёт по имени, а можно просто победить его мечом.",
             "Получена Книга имён."},
            {"jdh впервые молчит. Потом говорит всё сразу: осколок это кусок существа между мирами, которое раздаёт Искры.",
             "А ты не гений. Ты клон, «черновик». Настоящий учёный умер давно, а ты решил, что ты оригинал.",
             "Получено Сердце трещины. Используй его в мире-Трещине."},
            {"jdh опускается на чёрный камень. Он издевался над каждой твоей ошибкой всю схватку, но теперь смех стихает.",
             "Каждый побеждённый клон успел назвать своё имя. «{girl}» стоит рядом и ждёт, что ты решишь.",
             "Выбери свой конец."},
            {"Утро после выбора. Над миром висит тихий гул, а небо покрыто тридцатью тремя трещинами. Они не злые, они просто ждут.",
             "«{girl}» замечает: все осколки в мире поют одну ноту, и каждая следующая выше.",
             "Войди в Трещину ещё 3 раза: одна из дверей ведёт в Библиотеку."},
            {"Мир-Библиотека хранит всё забытое. Библиотекарь Мэриэль молча показывает на полки: каждая книга это чьё-то потерянное воспоминание.",
             "Среди них стоят книги, которые написал ты сам, не помня об этом. На одной странице голос настоящего учёного просит прощения."},
            {"Тридцать три трещины вспыхивают разом. Из центра неба смотрит существо без глаз. Это Дарящий: он раздаёт Искры тем, кто потянется.",
             "Ни злобы, ни добра. Только вопрос, на который никто пока не ответил."},
            {"Люди начинают получать Искры и радуются, пока не узнают цену. «{girl}» тянется к трещине сама, и ты едва успеваешь удержать её за руку.",
             "Вея, мироходец с чужими Искрами, забирает их у других и вплетает в свою. Она хочет остаться единственной."},
            {"Ты идёшь по следу похищенных Искр через миры зеркал, часов и тишины. Все старые места теперь выглядят иначе.",
             "Каждый раз, когда Вея выигрывает, ты теряешь что-то личное. Пора с этим кончать.",
             "Получено ещё одно Сердце трещины."},
            {"Вея падает и успевает сказать, что Дарящему нужны не Искры, а ответ.",
             "Существо спрашивает: «Что вы будете делать с силой, которую я дал?» Ответом должен стать поступок.",
             "Выбери свой конец."}
    };

    private static final String[][] JDH_TEXT = {
            {"Ты разглядываешь мёртвый мир через щель между реальностями, как коллекционер разглядывает дохлую бабочку. Скука смертная, пока приборы не дёргаются.",
             "Здесь кто-то разорвал границу миров и не умер. Без разрешения и без чертежей. Оскорбительно и безумно интересно."},
            {"Осколок шепчет чужим голосом: «Я просто хотел жить дольше». Ты фыркаешь: сам хочешь того же, только красивее, с корпорациями и манерами.",
             "Он напоминает Искру, но грубее и грязнее. Нужны образцы, и немедленно."},
            {"Осколки лезут тебе в голову. Ты гений и это терпишь, но мир становится слишком простым. Записываешь: «любопытный побочный эффект».",
             "Рядом с Санселло крутится клон-девочка. Если хочешь расположить её к себе, назови её командой /girlname <имя>.",
             "Получен Меч из осколка."},
            {"Ты разрываешь небо одним взмахом, потому что можешь, и потому что зрителей жалко лишать зрелища.",
             "Ты предлагаешь сделку: память в обмен на осколки. Не благотворительность, нужна Искра. Но за трещиной кто-то ждёт, и ты не уверен, что контролируешь ситуацию.",
             "Получен Разрывной портал. Войди в Трещину."},
            {"Три мира без людей: зеркал, часов и тишины. Ты обходишь их, как музей, и комментируешь вслух: этот скучный, этот трагичный.",
             "В мире тишины живёт Санселло, который никого не создавал. Ты почему-то не язвишь."},
            {"Клоны идут стеной, и ты вдруг понимаешь: они вели людей к выходу. Армия, которая ждала хозяина.",
             "Девочка протягивает Книгу имён. ПКМ по клону пощадит его, а меч его победит. Выбор за тобой.",
             "Получена Книга имён."},
            {"Ты нарочно молчишь. Ты знал правду с самого начала, но играл «потерянного».",
             "Осколок это кусок существа, раздающего Искры, а Санселло всего лишь клон-черновик. Тебя бесит одно: ты не знаешь, поглощает оно Искры или раздаёт.",
             "Получено Сердце трещины. Используй его в мире-Трещине."},
            {"Санселло опускается на колени. Магия гаснет, и перед тобой просто человек, уставший и испуганный.",
             "Ты ждал драмы, а получил паузу. «{girl}» молча смотрит на тебя.",
             "Выбери свой конец."},
            {"Ты возвращаешься без единой шутки: «Это не я! Хотя нет, это отчасти я». Приборы показывают, что кто-то проснулся.",
             "Небо в тридцати трёх трещинах, а осколки поют одну ноту. Ты ненавидишь, когда мир делает что-то без твоего разрешения.",
             "Войди в Трещину ещё 3 раза: одна из дверей ведёт в Библиотеку."},
            {"Библиотека одновременно бесит и восхищает: столько знаний и так плохо каталогизировано.",
             "Ты читаешь чужие воспоминания вслух с издёвкой, пока не находишь книгу про себя. В ней не хватает страницы о первой Искре."},
            {"Ты наконец узнаёшь то, что искал годами: Искра не паразит и не дар, а вопрос. Ты не умеешь на него отвечать, и это злит.",
             "Дарящий смотрит на тебя без глаз. Тебе впервые нечем язвить."},
            {"Ты берёшь «{girl}» в ученицы, ворча и язвя. Но не отпускаешь её ни на шаг.",
             "Вея собирает Искры. Ты передал ей часть данных, считая, что обманешь её. Ты ошибся, и это самое унизительное, что случалось с тобой."},
            {"Ты идёшь по следу Вей через все старые миры и в первый раз просишь помощи вслух. Санселло слышит.",
             "Вдвоём вы идёте не по любви, а потому что иначе не останется никого.",
             "Получено ещё одно Сердце трещины."},
            {"Вея падает. Её последняя фраза: Дарящему нужен не силовой ответ, а поступок.",
             "Существо спрашивает: «Что вы будете делать с силой, которую я дал?» Ты, самый умный из всех миров, молчишь.",
             "Выбери свой конец."}
    };

    private static final String[] BUTTONS_SANSELLO = {"[Принять осколок]", "[Отказаться от силы]", "[Список имён]"};
    private static final String[] BUTTONS_JDH = {"[Забрать его с собой]", "[Погасить осколки]", "[Каталог имён]"};

    private static final String[] BUTTONS2_SANSELLO = {"[Закрыть трещины]", "[Оставить небо открытым]", "[Уйти искать ответ]", "[Назвать мир по имени]"};
    private static final String[] BUTTONS2_JDH = {"[Запечатать всё]", "[Научить мир жить рядом]", "[Уйти вдвоём]", "[Дать ответ без слов]"};

    private static final String[][] ENDINGS2_SANSELLO = {
            {"Концовка сезона: Закрытые трещины",
             "Ты закрываешь тридцать три трещины одну за другой. Каждая забирает по одному воспоминанию, и ты отдаёшь свои.",
             "Остаётся «{girl}» с единственной Искрой. Ты учишь её закрывать двери, а не открывать их."},
            {"Концовка сезона: Открытое небо",
             "Ты оставляешь трещины открытыми. Мир учится жить рядом с Дарящим, медленно и опасно.",
             "У людей впервые появляется выбор, и «{girl}» первая решает им воспользоваться."},
            {"Концовка сезона: Вопрос без ответа",
             "Ты уходишь с существом в Междумирье искать ответ. «{girl}» остаётся хранить мир.",
             "Ты не знаешь, найдёшь ли его, но больше не боишься спрашивать."},
            {"Концовка сезона: Имя",
             "Ты ничего не отвечаешь, а просто называешь мир по имени. Следом называет «{girl}», потом Мэриэль, потом каждый, кто пришёл.",
             "Существо отвечает само: «Я отдал вам Искры, а вы дали друг другу имена». Трещины затягиваются, как шрамы."}
    };

    private static final String[][] ENDINGS2_JDH = {
            {"Концовка сезона: Запечатать всё",
             "Ты гасишь тридцать три трещины и бережёшь знание: теперь только ты знаешь, как их открыть.",
             "Контроль полный. «{girl}» смотрит на тебя без восторга, и это неприятно."},
            {"Концовка сезона: Мир рядом",
             "Ты оставляешь небо открытым и учишь мир правилам Искры, ворча и язвя на каждом уроке.",
             "Ты признаёшь, что впервые не хочешь быть единственным умным в комнате."},
            {"Концовка сезона: Уйти вдвоём",
             "Ты и Санселло уходите в Междумирье вместе с существом, чтобы искать ответ. «{girl}» берёт на себя мир.",
             "Ты брюзжишь всю дорогу, но идёшь рядом."},
            {"Концовка сезона: Ответ без слов",
             "Ты молча делаешь то, чего никогда не делал: отдаёшь свои записи тем, кто может ими пользоваться.",
             "Дарящий отвечает: «Я дал вам Искры, а вы дали друг другу имена». Трещины затягиваются, как шрамы."}
    };

    private static final String[][] ENDINGS_SANSELLO = {
            {"Концовка: Хранитель трещин",
             "Ты принимаешь осколок. Имя уходит первым, потом лицо, потом страх. Трещины открываются по всему небу, и ты становишься их стражем.",
             "Помнит тебя только одна: «{girl}». Она каждый вечер произносит твоё старое имя, и тебе этого достаточно."},
            {"Концовка: Черновик, ставший человеком",
             "Ты отбрасываешь осколок. Магия уходит, и вместе с ней уходит шёпот.",
             "Клоны получают имена и встают из пепла. Ты исчезаешь так тихо, как исчезают черновики, оставив им мир, который начинается заново."},
            {"Концовка: Список имён",
             "Книга имён раскрывается сама. Ты читаешь имя за именем, и пепел отвечает шагами: лавочник, пекарь, девочка с корзиной.",
             "Магия уходит, возврата в Междумирье нет. Зато у тебя есть жизнь, и у неё есть название, которое придумала «{girl}»."}
    };

    private static final String[][] ENDINGS_JDH = {
            {"Концовка: Партнёр",
             "Ты протягиваешь руку так, словно делаешь ему огромное одолжение. Санселло долго смотрит на неё, а потом берёт.",
             "Ты уже подсчитываешь, как использовать его знания, и называешь это «сотрудничеством». Но один раз всё же признаёшь вслух, что ошибся."},
            {"Концовка: Единственный хранитель",
             "Ты кладёшь ладонь на последний осколок и гасишь его. Трещины закрываются одна за другой, а ты демонстративно кланяешься пустоте.",
             "Ты единственный, кто знает правду, и правила теперь диктуешь ты. Это тебя пугает."},
            {"Концовка: Каталог имён",
             "Ты записываешь имена в планшет, и впервые за сто лет не шутишь. Жители возвращаются один за другим.",
             "Самый умный из всех миров вдруг обнаруживает, что ему не всё равно, и «{girl}» делает вид, что не заметила."}
    };

    // ------------------------------------------------------------------

    public static void startRole(ServerPlayer sp, PlayerRole role) {
        PlayerData d = PlayerData.get(sp);
        d.role = role;
        d.resetProgress();
        give(sp, ModItems.JOURNAL.get());
        if (role == PlayerRole.SANSELLO) {
            give(sp, ModItems.CLONE_DECOY.get());
            give(sp, ModItems.SHARD_BLAST.get());
        } else if (role == PlayerRole.JDH) {
            give(sp, ModItems.RIFT_STEP.get());
            give(sp, ModItems.SHARD_SENSE.get());
        }
        enter(sp, d, 1);
    }

    private static void give(ServerPlayer sp, Item item) {
        ItemHandlerHelper.giveItemToPlayer(sp, new ItemStack(item));
    }

    private static boolean ready(PlayerData d) {
        return switch (d.chapter) {
            case 1 -> d.shards >= 1;
            case 2 -> d.shards >= 3;
            case 3 -> d.shards >= 5;
            case 4 -> d.riftVisits >= 1;
            case 5 -> d.cloneKills >= 5;
            case 6 -> d.shards >= 12 && d.cloneKills >= 10;
            case 9 -> d.riftVisits >= 4;
            case 10 -> d.pages >= 5;
            case 11 -> d.shards >= 22;
            case 12 -> d.pages >= 10;
            default -> false;
        };
    }

    public static void check(ServerPlayer sp) {
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) return;
        while (((d.chapter >= 1 && d.chapter <= 6) || (d.chapter >= 9 && d.chapter <= 12)) && ready(d)) {
            enter(sp, d, d.chapter + 1);
        }
    }

    public static void enter(ServerPlayer sp, PlayerData d, int chapter) {
        d.chapter = chapter;
        switch (chapter) {
            case 1 -> MapGiver.crater(sp);
            case 2 -> MapGiver.lab(sp);
            case 10 -> MapGiver.library(sp);
            case 1 -> ItemHandlerHelper.giveItemToPlayer(sp, StructureGen.makeMap(sp.getServer().overworld()));
            case 3 -> give(sp, ModItems.SHARD_SWORD.get());
            case 4 -> give(sp, ModItems.RIFT_PORTAL.get());
            case 6 -> give(sp, ModItems.NAME_BOOK.get());
            case 7, 13 -> give(sp, ModItems.HEART.get());
            default -> { }
        }
        sp.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.MASTER, 1f, 1f);
        Fx.title(sp, "Глава " + chapter, TITLES[chapter - 1]);
        Fx.burst(sp);
        show(sp);
        ModNetwork.sync(sp);
    }

    public static void onBossDefeated(ServerPlayer sp) {
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) return;
        if (d.chapter == 7) {
            d.bossDefeated = true;
            enter(sp, d, 8);
        } else if (d.chapter == 13) {
            enter(sp, d, 14);
        }
    }

    private static boolean secretOpen(PlayerData d) {
        return !d.girlName.isEmpty() && d.spared >= 5;
    }

    private static boolean secret2Open(PlayerData d) {
        return d.ending == 3 && !d.girlName.isEmpty();
    }

    public static void choose(ServerPlayer sp, int n) {
        PlayerData d = PlayerData.get(sp);
        if (d.chapter == 8) {
            if (n > 3) {
                sp.sendSystemMessage(Component.literal("Здесь доступны концовки 1-3.").withStyle(ChatFormatting.GRAY));
                return;
            }
            if (n == 3 && !secretOpen(d)) {
                sp.sendSystemMessage(Component.literal("Эта концовка закрыта: назови девочку (/girlname) и пощади хотя бы 5 клонов Книгой имён.")
                        .withStyle(ChatFormatting.GRAY));
                return;
            }
            d.ending = n;
            String[] e = (d.role == PlayerRole.SANSELLO ? ENDINGS_SANSELLO : ENDINGS_JDH)[n - 1];
            showEnding(sp, d, e);
            sp.sendSystemMessage(Component.literal("Но история не закончилась. Начинается Сезон 2.").withStyle(ChatFormatting.GOLD));
            enter(sp, d, 9);
        } else if (d.chapter == 14) {
            if (n == 4 && !secret2Open(d)) {
                sp.sendSystemMessage(Component.literal("Эта концовка закрыта: нужна тайная концовка сезона 1 и имя девочки.")
                        .withStyle(ChatFormatting.GRAY));
                return;
            }
            d.ending2 = n;
            d.chapter = 15;
            ModNetwork.sync(sp);
            show(sp);
        } else {
            sp.sendSystemMessage(Component.literal("Выбор станет доступен после финального боя.").withStyle(ChatFormatting.GRAY));
        }
    }

    private static void showEnding(ServerPlayer sp, PlayerData d, String[] e) {
        Fx.title(sp, e[0], "");
        Fx.burst(sp);
        sp.sendSystemMessage(Component.literal("== " + e[0] + " ==").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
        for (int i = 1; i < e.length; i++) {
            sp.sendSystemMessage(Component.literal(fill(d, e[i])).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
    }

    // ------------------------------------------------------------------

    private static String fill(PlayerData d, String line) {
        return line.replace("{girl}", d.girlName.isEmpty() ? "девочка" : d.girlName);
    }

    public static void show(ServerPlayer sp) {
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) return;
        if (d.chapter >= 15) {
            String[] e = (d.role == PlayerRole.SANSELLO ? ENDINGS2_SANSELLO : ENDINGS2_JDH)[Math.max(0, d.ending2 - 1)];
            showEnding(sp, d, e);
            sp.sendSystemMessage(Component.literal("Обе истории завершены. Спасибо за игру!").withStyle(ChatFormatting.GOLD));
            return;
        }
        if (d.chapter < 1) return;
        int ch = d.chapter;
        String[] lines = (d.role == PlayerRole.SANSELLO ? SANSELLO_TEXT : JDH_TEXT)[ch - 1];
        sp.sendSystemMessage(Component.literal("== Глава " + ch + ": " + TITLES[ch - 1] + " ==")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        for (String line : lines) {
            sp.sendSystemMessage(Component.literal(fill(d, line)).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
        sp.sendSystemMessage(Component.literal("Цель: " + OBJECTIVES[ch - 1]).withStyle(ChatFormatting.YELLOW));
        if (ch == 8 || ch == 14) {
            boolean second = ch == 14;
            String[] b = second ? (d.role == PlayerRole.SANSELLO ? BUTTONS2_SANSELLO : BUTTONS2_JDH)
                    : (d.role == PlayerRole.SANSELLO ? BUTTONS_SANSELLO : BUTTONS_JDH);
            int count = second ? (secret2Open(d) ? 4 : 3) : (secretOpen(d) ? 3 : 2);
            ChatFormatting[] colors = {ChatFormatting.RED, ChatFormatting.AQUA, ChatFormatting.YELLOW, ChatFormatting.GREEN};
            for (int i = 0; i < count; i++) {
                final int n = i + 1;
                final ChatFormatting color = colors[i];
                sp.sendSystemMessage(Component.literal(b[i]).withStyle(st -> st
                        .withColor(color)
                        .withBold(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/ending " + n))));
            }
        }
    }

    public static void showJournal(ServerPlayer sp) {
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) {
            sp.sendSystemMessage(Component.literal("Сначала выбери роль: /role set sanselo или /role set jdh"));
            return;
        }
        show(sp);
        sp.sendSystemMessage(Component.literal("Осколков: " + d.shards + " | Клонов побеждено или пощажено: " + d.cloneKills
                + " (пощажено " + d.spared + ") | Страниц памяти: " + d.pages | Визитов в Трещину: " + d.riftVisits
                + (d.girlName.isEmpty() ? "" : " | Девочку зовут: " + d.girlName)).withStyle(ChatFormatting.DARK_AQUA));
        sp.sendSystemMessage(Component.literal("Места на карте (получить карту: /storymap):").withStyle(ChatFormatting.GRAY));
        var ow = sp.getServer().overworld();
        for (int i = 0; i < StructureGen.SITES.length; i++) {
            BlockPos p = StructureGen.siteXZ(ow, i);
            sp.sendSystemMessage(Component.literal(" - " + StructureGen.SITES[i].name() + ": " + p.getX() + ", " + p.getZ()).withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
